from fastapi import FastAPI, HTTPException, Depends, Body, Path
from sqlalchemy.orm import Session
from typing import List

from my_fastapi_app import database
from my_fastapi_app import models
from my_fastapi_app.models import Post



app = FastAPI()

# Ініціалізація бази даних
models.Base.metadata.create_all(bind=database.engine)

# Dependency для отримання сесії бази даних
def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/version")
async def version():
    return {"version": "1.0"}

@app.get("/posts", response_model=List[models.Post])
async def get_posts(db: Session = Depends(get_db)):
    return db.query(models.Post).all()

@app.post("/posts", response_model=models.Post)
async def create_post(title: str = Body(...), content: str = Body(...), db: Session = Depends(get_db)):
    new_post = models.Post(title=title, content=content)
    db.add(new_post)
    db.commit()
    db.refresh(new_post)
    return new_post

@app.put("/posts/{post_id}", response_model=models.Post)
async def update_post(post_id: int, title: str = Body(...), content: str = Body(...), db: Session = Depends(get_db)):
    post = db.query(models.Post).filter(models.Post.id == post_id).first()
    if post is None:
        raise HTTPException(status_code=404, detail="Пост не знайдено")
    post.title = title
    post.content = content
    db.commit()
    db.refresh(post)
    return post

@app.delete("/posts/{post_id}")
async def delete_post(post_id: int, db: Session = Depends(get_db)):
    post = db.query(models.Post).filter(models.Post.id == post_id).first()
    if post is None:
        raise HTTPException(status_code=404, detail="Пост не знайдено")
    db.delete(post)
    db.commit()
    return {"message": f"Пост з ідентифікатором {post_id} видалено"}

@app.post("/comments", response_model=models.Comment)
async def create_comment(post_id: int = Body(...), content: str = Body(...), db: Session = Depends(get_db)):
    new_comment = models.Comment(post_id=post_id, content=content)
    db.add(new_comment)
    db.commit()
    db.refresh(new_comment)
    return new_comment

@app.post("/users", response_model=models.User)
async def create_user(username: str = Body(...), email: str = Body(...), hashed_password: str = Body(...), db: Session = Depends(get_db)):
    new_user = models.User(username=username, email=email, hashed_password=hashed_password)
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
